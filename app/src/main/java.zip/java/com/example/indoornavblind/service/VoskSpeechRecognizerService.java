package com.example.indoornavblind.service;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.RecognitionListener;
import org.vosk.android.SpeechService;
import org.vosk.android.StorageService;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Vosk 离线语音识别服务
 * 
 * 优势：
 * 1. 完全离线，无需网络
 * 2. 支持自定义语法（固定指令识别率接近100%）
 * 3. 低延迟（~0.5秒）
 * 4. 支持多语言
 */
public class VoskSpeechRecognizerService {
    private static final String TAG = "VoskSpeechRecognizer";
    
    // Vosk 核心组件
    private Model model;
    private SpeechService speechService;
    private Context context;
    private OnRecognitionListener listener;
    
    // 状态
    private boolean isInitialized = false;
    private boolean isListening = false;
    
    // Handler
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    
    /**
     * 初始化服务（异步加载模型）
     * @param context 上下文
     * @param modelPath 模型路径（可选，为null则使用默认小模型）
     */
    public void init(Context context, String modelPath) {
        this.context = context;
        
        // 异步加载模型，避免阻塞 UI
        new Thread(() -> {
            try {
                // 如果没指定模型，下载轻量级中文模型（~40MB）
                if (modelPath == null) {
                    StorageService.unpack(context, "vosk-model-small-cn-0.22",
                        "model", (model) -> {
                            this.model = model;
                            setupRecognizer();
                        }, (exception) -> {
                            notifyError("模型加载失败: " + exception.getMessage());
                        });
                } else {
                    // 使用指定的模型文件
                    model = new Model(modelPath);
                    setupRecognizer();
                }
            } catch (IOException e) {
                Log.e(TAG, "模型初始化失败", e);
                notifyError("模型初始化失败: " + e.getMessage());
            }
        }).start();
    }
    
    /**
     * 设置识别器（支持自定义语法）
     */
    private void setupRecognizer() {
        try {
            // 创建识别器（16kHz 采样率）
            Recognizer recognizer = new Recognizer(model, 16000.0f);
            
            // 【关键】设置语法规则 - 只识别预设指令
            // 这会大幅提升固定指令的识别准确率
            String grammar = grammar();
            recognizer.setGrammar(grammar);
            
            // 创建语音服务
            speechService = new SpeechService(recognizer, 16000.0f);
            speechService.startListening(recognitionListener);
            
            isInitialized = true;
            Log.d(TAG, "Vosk 初始化成功");
            
        } catch (IOException e) {
            Log.e(TAG, "识别器创建失败", e);
            notifyError("识别器创建失败");
        }
    }
    
    /**
     * 构建语法规则（基于 LocalIntentEngine 的指令）
     * 这里定义了你的 App 支持的所有语音指令
     */
    private String grammar() {
        return "[" +
            // 导航指令
            "\"去浴室\", \"去门口\", \"去楼梯\", \"去电梯\", " +
            "\"去厕所\", \"去洗手间\", \"去出口\", \"去入口\", " +
            
            // 定位指令
            "\"我在哪\", \"我在哪里\", \"当前位置\", \"定位\", " +
            
            // 查询指令
            "\"附近有什么\", \"周围有什么\", \"查询附近\", " +
            "\"导航进度\", \"还有多远\", \"快到了吗\", " +
            
            // 控制指令
            "\"开始导航\", \"停止导航\", \"取消导航\", " +
            "\"重复\", \"再说一遍\", " +
            "\"加快速度\", \"减慢速度\", " +
            
            // 帮助指令
            "\"帮助\", \"怎么用\", \"说明\", " +
            
            // 设置指令
            "\"打开设置\", \"设置\", " +
            
            // 紧急指令
            "\"紧急求助\", \"帮我\", \"求助\"" +
            "]";
    }
    
    /**
     * Vosk 识别监听器
     */
    private RecognitionListener recognitionListener = new RecognitionListener() {
        @Override
        public void onPartialResult(String hypothesis) {
            // 部分结果（可用于实时反馈）
            Log.d(TAG, "部分结果: " + hypothesis);
        }
        
        @Override
        public void onResult(String hypothesis) {
            // 最终结果
            isListening = false;
            
            try {
                JSONObject result = new JSONObject(hypothesis);
                String text = result.optString("text", "");
                
                if (!text.isEmpty()) {
                    Log.d(TAG, "识别结果: " + text);
                    notifyResult(text);
                } else {
                    notifyError("未识别到语音");
                }
            } catch (Exception e) {
                Log.e(TAG, "解析结果失败", e);
                notifyError("解析结果失败");
            }
        }
        
        @Override
        public void onFinalResult(String hypothesis) {
            // 最终结果（会话结束）
            onResult(hypothesis);
        }
        
        @Override
        public void onError(Exception exception) {
            isListening = false;
            Log.e(TAG, "识别错误", exception);
            notifyError("识别错误: " + exception.getMessage());
        }
        
        @Override
        public void onTimeout() {
            isListening = false;
            notifyError("识别超时");
        }
    };
    
    /**
     * 开始语音识别（完全离线）
     */
    public void startListening() {
        if (!isInitialized) {
            notifyError("语音识别服务未初始化");
            return;
        }
        
        if (isListening) {
            Log.d(TAG, "已在监听中");
            return;
        }
        
        isListening = true;
        speechService.startListening(recognitionListener);
        Log.d(TAG, "开始语音识别（离线模式）");
    }
    
    /**
     * 停止识别
     */
    public void stopListening() {
        if (speechService != null) {
            speechService.stop();
        }
        isListening = false;
    }
    
    /**
     * 重置识别器（用于重新开始识别）
     */
    public void reset() {
        if (speechService != null) {
            speechService.reset();
        }
    }
    
    /**
     * 销毁资源
     */
    public void destroy() {
        if (speechService != null) {
            speechService.shutdown();
            speechService = null;
        }
        if (model != null) {
            model.close();
            model = null;
        }
        isInitialized = false;
        listener = null;
        context = null;
    }
    
    /**
     * 设置识别监听器
     */
    public void setRecognitionListener(OnRecognitionListener listener) {
        this.listener = listener;
    }
    
    /**
     * 通知识别结果
     */
    private void notifyResult(String text) {
        if (listener != null) {
            mainHandler.post(() -> {
                ArrayList<String> results = new ArrayList<>();
                results.add(text);
                listener.onResult(results);
            });
        }
    }
    
    /**
     * 通知错误
     */
    private void notifyError(String errorMsg) {
        if (listener != null) {
            mainHandler.post(() -> listener.onError(errorMsg));
        }
    }
    
    /**
     * 检查是否正在监听
     */
    public boolean isListening() {
        return isListening;
    }
    
    /**
     * 检查是否已初始化
     */
    public boolean isInitialized() {
        return isInitialized;
    }
    
    // 识别结果回调接口（保持与原接口一致，方便替换）
    public interface OnRecognitionListener {
        void onResult(ArrayList<String> results);
        void onError(String errorMsg);
    }
}
